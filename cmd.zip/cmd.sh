#!/bin/bash
git-cz
